﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_Pert7.Models
{
    public class User
    {
        public Int32 Id { get; set; }
        public String Name { get; set; }
        public String Username { get; set; }
        public String Password { get; set; }
        public String Status { get; set; } 

    }
}
